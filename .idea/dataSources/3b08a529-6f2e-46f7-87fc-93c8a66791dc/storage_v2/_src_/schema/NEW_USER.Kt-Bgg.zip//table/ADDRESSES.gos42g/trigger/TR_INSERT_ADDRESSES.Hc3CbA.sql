create trigger TR_INSERT_ADDRESSES
    before insert
    on ADDRESSES
    for each row
BEGIN
    SELECT SEQ_ADDRESSES.nextval
    INTO :new.ID
    FROM dual;
END;
/

