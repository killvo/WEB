create trigger TR_INSERT_PROCEDURES
    before insert
    on PROCEDURES
    for each row
BEGIN
    SELECT SEQ_PROCEDURES.nextval
    INTO :new.ID
    FROM dual;
END;
/

