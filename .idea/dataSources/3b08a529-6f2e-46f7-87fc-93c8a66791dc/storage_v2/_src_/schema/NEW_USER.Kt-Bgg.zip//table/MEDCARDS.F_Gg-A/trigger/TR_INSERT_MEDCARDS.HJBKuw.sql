create trigger TR_INSERT_MEDCARDS
    before insert
    on MEDCARDS
    for each row
BEGIN
    SELECT SEQ_MEDCARDS.nextval
    INTO :new.ID
    FROM dual;
END;
/

