create trigger TR_INSERT_PROC_LIST
    before insert
    on PROC_LIST
    for each row
BEGIN
    SELECT SEQ_PROC_LIST.nextval
    INTO :new.ID
    FROM dual;
END;
/

