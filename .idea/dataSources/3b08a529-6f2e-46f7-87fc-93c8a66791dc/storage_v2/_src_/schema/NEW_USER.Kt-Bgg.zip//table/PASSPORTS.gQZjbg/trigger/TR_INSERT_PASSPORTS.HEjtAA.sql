create trigger TR_INSERT_PASSPORTS
    before insert
    on PASSPORTS
    for each row
BEGIN
    SELECT SEQ_PASSPORTS.nextval
    INTO :new.ID
    FROM dual;
END;
/

