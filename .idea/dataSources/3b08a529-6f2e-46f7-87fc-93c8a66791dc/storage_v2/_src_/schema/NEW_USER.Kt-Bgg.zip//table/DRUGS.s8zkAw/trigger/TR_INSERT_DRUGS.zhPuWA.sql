create trigger TR_INSERT_DRUGS
    before insert
    on DRUGS
    for each row
BEGIN
    SELECT SEQ_DRUGS.nextval
    INTO :new.ID
    FROM dual;
END;
/

