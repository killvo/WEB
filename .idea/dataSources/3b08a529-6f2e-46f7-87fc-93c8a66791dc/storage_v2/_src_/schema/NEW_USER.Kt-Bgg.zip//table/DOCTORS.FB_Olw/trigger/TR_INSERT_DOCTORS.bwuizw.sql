create trigger TR_INSERT_DOCTORS
    before insert
    on DOCTORS
    for each row
BEGIN
SELECT SEQ_DOCTORS.nextval
INTO :new.ID
FROM dual;
END;
/

