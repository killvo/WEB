create trigger TR_INSERT_PRESCRIPTIONS
    before insert
    on PRESCRIPTIONS
    for each row
BEGIN
    SELECT SEQ_PRESCRIPTIONS.nextval
    INTO :new.ID
    FROM dual;
END;
/

