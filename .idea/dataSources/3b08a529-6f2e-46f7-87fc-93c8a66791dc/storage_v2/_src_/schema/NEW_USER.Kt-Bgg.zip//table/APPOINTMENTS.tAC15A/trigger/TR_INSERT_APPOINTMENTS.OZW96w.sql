create trigger TR_INSERT_APPOINTMENTS
    before insert
    on APPOINTMENTS
    for each row
BEGIN
    SELECT SEQ_APPOINTMENTS.nextval
    INTO :new.ID
    FROM dual;
END;
/

