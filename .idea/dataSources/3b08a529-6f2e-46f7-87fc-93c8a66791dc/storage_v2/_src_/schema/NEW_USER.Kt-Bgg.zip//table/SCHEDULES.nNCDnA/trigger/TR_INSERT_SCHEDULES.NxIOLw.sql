create trigger TR_INSERT_SCHEDULES
    before insert
    on SCHEDULES
    for each row
BEGIN
    SELECT SEQ_SCHEDULES.nextval
    INTO :new.ID
    FROM dual;
END;
/

