create trigger TR_INSERT_DISEASES
    before insert
    on DISEASES
    for each row
BEGIN
    SELECT SEQ_DISEASES.nextval
    INTO :new.ID
    FROM dual;
END;
/

