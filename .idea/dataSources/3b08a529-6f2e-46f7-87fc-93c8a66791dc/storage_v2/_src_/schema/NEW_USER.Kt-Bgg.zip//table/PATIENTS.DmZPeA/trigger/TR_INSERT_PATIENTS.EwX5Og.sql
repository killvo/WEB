create trigger TR_INSERT_PATIENTS
    before insert
    on PATIENTS
    for each row
BEGIN
    SELECT SEQ_PATIENTS.nextval
    INTO :new.ID
    FROM dual;
END;
/

