create trigger TR_INSERT_HAS_MEDCARD
    before insert
    on HAS_MEDCARD
    for each row
BEGIN
    SELECT SEQ_HAS_MEDCARD.nextval
    INTO :new.ID
    FROM dual;
END;
/

